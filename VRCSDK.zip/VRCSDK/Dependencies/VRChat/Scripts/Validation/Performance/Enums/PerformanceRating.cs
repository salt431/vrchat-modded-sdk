namespace VRC.Enums.Validation.Performance
{
    public enum PerformanceRating
    {
        None = 0,
        Excellent = 5,
        Good = 2,
        Medium = 3,
        Poor = 4,
        VeryPoor = 1
    }
}
