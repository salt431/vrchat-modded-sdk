namespace VRC.SDKBase.Validation.Performance
{
    public enum PerformanceInfoDisplayLevel
    {
        None,

        Verbose,
        Info,
        Warning,
        Error
    }
}
