namespace VRC.SDKBase.Validation.Performance
{
    public enum PerformanceRating
    {
        None = 0,
        VeryPoor = 1,
	Good = 2,
	Medium = 3,
	Poor = 4,
	Excellent = 5

    }
}
